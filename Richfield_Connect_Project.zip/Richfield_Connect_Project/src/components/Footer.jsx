import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <p className="footer-brand">RICHFIELD <span>CONNECT</span></p>
          <p className="footer-description">A welcoming academic space for exchanging ideas, building connections and celebrating progress.</p>
        </div>
        <div className="footer-links">
          <p className="footer-title">Explore</p>
          <Link to="/">Home</Link><Link to="/about">About</Link><Link to="/feed">Community feed</Link><Link to="/profile">My profile</Link>
        </div>
        <div className="footer-links">
          <p className="footer-title">Get started</p>
          <Link to="/signup">Create a profile</Link>
          <Link to="/about">Community guidelines</Link>
          <span className="footer-note">Made to learn, share and grow.</span>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} Richfield Connect</span>
      </div>
    </footer>
  );
}

export default Footer;
