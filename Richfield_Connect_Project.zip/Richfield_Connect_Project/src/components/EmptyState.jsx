import { Link } from 'react-router-dom';

function EmptyState({ icon = '✦', title, text, action, to }) {
  return (
    <div className="empty-state">
      <span className="empty-icon" aria-hidden="true">{icon}</span>
      <h2>{title}</h2>
      <p>{text}</p>
      {action && to && <Link className="button button-primary" to={to}>{action} <span aria-hidden="true">↗</span></Link>}
    </div>
  );
}
export default EmptyState;
