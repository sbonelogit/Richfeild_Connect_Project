import { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { getInitials, readableTimestamp, uniqueId } from '../utils/formatters';

function CreatePost() {
  const { user, dispatch } = useAppContext();
  const [content, setContent] = useState('');
  const [error, setError] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    if (!content.trim()) {
      setError('Write something before sharing your post.');
      return;
    }
    if (!user) return;

    const now = new Date();
    dispatch({
      type: 'ADD_POST',
      payload: {
        id: uniqueId(),
        username: user.fullName,
        authorStudentNumber: user.studentNumber,
        timestamp: readableTimestamp(now),
        createdAt: now.toISOString(),
        content: content.trim(),
        likes: 0,
        liked: false,
        comments: [],
      },
    });
    setContent('');
    setError('');
  }

  return (
    <form className="create-post-card" onSubmit={handleSubmit} noValidate>
      <div className="composer-header"><span className="avatar avatar-small">{getInitials(user?.fullName)}</span><div><strong>Share with your community</strong><p>Every great idea starts with a conversation.</p></div></div>
      <label className="sr-only" htmlFor="postContent">Write your post</label>
      <textarea id="postContent" className="post-textarea" value={content} maxLength={1000}
        onChange={(e) => { setContent(e.target.value); if (e.target.value.trim()) setError(''); }}
        placeholder="Share a study tip, project milestone or interesting question..." rows={4} />
      {error && <span role="alert" className="field-error">{error}</span>}
      <div className="composer-bottom"><span className="composer-counter">{content.length} / 1000 characters</span><button className="button button-primary" type="submit">Publish post <span aria-hidden="true">↗</span></button></div>
    </form>
  );
}
export default CreatePost;
