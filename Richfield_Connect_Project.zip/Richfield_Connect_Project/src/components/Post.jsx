import { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { getInitials, readableTimestamp, uniqueId } from '../utils/formatters';

function Post({ post }) {
  const { user, dispatch } = useAppContext();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(post.content);
  const [comment, setComment] = useState('');
  const [commentError, setCommentError] = useState('');
  const isOwner = Boolean(user && user.studentNumber === post.authorStudentNumber);
  const comments = Array.isArray(post.comments) ? post.comments : [];

  function handleDelete() {
    // A native confirmation is required by Section 5.6.4 of the assignment.
    if (window.confirm('Delete this post permanently?')) {
      dispatch({ type: 'DELETE_POST', payload: post.id });
    }
  }

  function saveEdit(event) {
    event.preventDefault();
    if (!draft.trim()) return;
    dispatch({ type: 'UPDATE_POST', payload: { id: post.id, content: draft.trim() } });
    setEditing(false);
  }

  function addComment(event) {
    event.preventDefault();
    if (!comment.trim()) { setCommentError('Please write a comment first.'); return; }
    if (!user) return;
    dispatch({
      type: 'ADD_COMMENT',
      payload: {
        postId: post.id,
        comment: { id: uniqueId(), author: user.fullName, content: comment.trim(), timestamp: readableTimestamp() },
      },
    });
    setComment('');
    setCommentError('');
  }

  return (
    <article className="post-card">
      <div className="post-top">
        <div className="post-author"><div className="avatar avatar-small avatar-alt">{getInitials(post.username)}</div><div><strong>{post.username}</strong><span>{post.timestamp}{post.edited ? ' · Edited' : ''}</span></div></div>
        {isOwner && <div className="post-owner-actions"><button type="button" className="text-button" onClick={() => { setDraft(post.content); setEditing(!editing); }}>{editing ? 'Cancel' : 'Edit'}</button><button type="button" className="text-button danger-text" onClick={handleDelete}>Delete</button></div>}
      </div>
      {editing ? (
        <form onSubmit={saveEdit} className="edit-form"><label className="sr-only" htmlFor={`edit-${post.id}`}>Edit post</label><textarea id={`edit-${post.id}`} rows={3} value={draft} onChange={(e) => setDraft(e.target.value)} maxLength={1000} /><button type="submit" className="button button-small button-primary" disabled={!draft.trim()}>Save changes</button></form>
      ) : <p className="post-content">{post.content}</p>}
      <div className="post-meta"><span>✦ Shared with Richfield Connect</span><span>{comments.length} {comments.length === 1 ? 'comment' : 'comments'}</span></div>
      <div className="post-actions">
        <button type="button" onClick={() => dispatch({ type: 'TOGGLE_LIKE', payload: post.id })}
          className={`like-button ${post.liked ? 'liked' : ''}`} aria-pressed={Boolean(post.liked)}>
          <span aria-hidden="true">{post.liked ? '♥' : '♡'}</span> {post.liked ? 'Liked' : 'Like'} <span className="like-count">{post.likes}</span>
        </button>
        <span className="comment-count" aria-label={`${comments.length} comments`}>◇ Discussion</span>
      </div>
      {comments.length > 0 && <div className="comments-list">{comments.map((item) => (
        <div className="comment-row" key={item.id}><span className="comment-avatar">{getInitials(item.author)}</span><div className="comment-bubble"><strong>{item.author}</strong><span>{item.timestamp}</span><p>{item.content}</p></div></div>
      ))}</div>}
      {user && <form className="comment-form" onSubmit={addComment} noValidate>
        <label className="sr-only" htmlFor={`comment-${post.id}`}>Add a comment</label>
        <input id={`comment-${post.id}`} value={comment} maxLength={350} placeholder="Add a thoughtful comment..." onChange={(e) => { setComment(e.target.value); if (e.target.value.trim()) setCommentError(''); }} />
        <button className="button button-small button-outline" type="submit">Comment</button>
        {commentError && <span className="field-error comment-error" role="alert">{commentError}</span>}
      </form>}
    </article>
  );
}
export default Post;
