function PageHeading({ eyebrow, title, description, align = 'left' }) {
  return (
    <div className={`page-heading ${align === 'center' ? 'center' : ''}`}>
      <span className="eyebrow">{eyebrow}</span>
      <h1>{title}</h1>
      {description && <p>{description}</p>}
    </div>
  );
}
export default PageHeading;
