import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import ProfilePreview from './ProfilePreview';
import { useAppContext } from '../context/AppContext';
import { CAMPUSES, INTERESTS } from '../utils/constants';
import { validateRegistration } from '../utils/validation';

const emptyForm = {
  fullName: '', studentNumber: '', campus: '', email: '', password: '',
  confirmPassword: '', interests: [], bio: '', acceptedTerms: false,
};

function FieldError({ message, id }) {
  return message ? <span className="field-error" id={id} role="alert">{message}</span> : null;
}

function SignUpForm() {
  const [form, setForm] = useState(emptyForm);
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const { dispatch } = useAppContext();
  const navigate = useNavigate();

  // Errors are derived directly from current form state; corrected fields clear immediately.
  const errors = validateRegistration(form);
  const visibleError = (field) => (touched[field] || submitted ? errors[field] : undefined);
  const touch = (field) => setTouched((current) => ({ ...current, [field]: true }));
  const update = (field, value) => setForm((current) => ({ ...current, [field]: value }));
  const toggleInterest = (interest) => {
    setForm((current) => ({
      ...current,
      interests: current.interests.includes(interest)
        ? current.interests.filter((item) => item !== interest)
        : [...current.interests, interest],
    }));
  };

  function handleSubmit(event) {
    event.preventDefault(); // The assessment explicitly requires no browser form-page reload.
    setSubmitted(true);
    if (Object.keys(validateRegistration(form)).length > 0) return;

    // Browser storage is not a secure password store. The password is validated but
    // deliberately NOT persisted; this project does not implement authentication.
    const profile = {
      fullName: form.fullName.trim(),
      studentNumber: form.studentNumber,
      campus: form.campus,
      email: form.email.trim().toLowerCase(),
      interests: [...form.interests],
      bio: form.bio.trim(),
      acceptedTerms: form.acceptedTerms,
      registeredAt: new Date().toISOString(),
    };
    dispatch({ type: 'REGISTER_USER', payload: profile });
    navigate('/profile'); // Programmatic route change through React Router useNavigate.
  }

  return (
    <div className="signup-grid">
      <form className="form-card" onSubmit={handleSubmit} noValidate>
        <div className="form-heading"><span className="form-step">01 / YOUR DETAILS</span><h2>Create your student profile</h2><p>All fields are required unless stated otherwise.</p></div>
        <div className="form-grid">
          <div className="form-field field-wide">
            <label htmlFor="fullName">Full name <span className="required">*</span></label>
            <input id="fullName" autoComplete="name" placeholder="e.g. Zanele Mkhize" value={form.fullName}
              onChange={(e) => update('fullName', e.target.value)} onBlur={() => touch('fullName')}
              aria-invalid={!!visibleError('fullName')} aria-describedby={visibleError('fullName') ? 'name-error' : undefined} />
            <FieldError message={visibleError('fullName')} id="name-error" />
          </div>
          <div className="form-field">
            <label htmlFor="studentNumber">Student number <span className="required">*</span></label>
            <input id="studentNumber" inputMode="numeric" placeholder="Minimum 6 digits" value={form.studentNumber}
              onChange={(e) => update('studentNumber', e.target.value.replace(/\D/g, ''))} onBlur={() => touch('studentNumber')}
              aria-invalid={!!visibleError('studentNumber')} aria-describedby={visibleError('studentNumber') ? 'number-error' : undefined} />
            <FieldError message={visibleError('studentNumber')} id="number-error" />
          </div>
          <div className="form-field">
            <label htmlFor="campus">Campus <span className="required">*</span></label>
            <select id="campus" value={form.campus} onChange={(e) => update('campus', e.target.value)}
              onBlur={() => touch('campus')} aria-invalid={!!visibleError('campus')}>
              <option value="">Select your campus</option>
              {CAMPUSES.map((campus) => <option key={campus} value={campus}>{campus}</option>)}
            </select>
            <FieldError message={visibleError('campus')} id="campus-error" />
          </div>
          <div className="form-field field-wide">
            <label htmlFor="email">Email address <span className="required">*</span></label>
            <input id="email" type="email" autoComplete="email" placeholder="student@example.com" value={form.email}
              onChange={(e) => update('email', e.target.value)} onBlur={() => touch('email')}
              aria-invalid={!!visibleError('email')} />
            <FieldError message={visibleError('email')} id="email-error" />
          </div>
          <div className="form-field">
            <label htmlFor="password">Password <span className="required">*</span></label>
            <input id="password" type="password" autoComplete="new-password" placeholder="8+ characters" value={form.password}
              onChange={(e) => update('password', e.target.value)} onBlur={() => touch('password')}
              aria-invalid={!!visibleError('password')} />
            <FieldError message={visibleError('password')} id="password-error" />
          </div>
          <div className="form-field">
            <label htmlFor="confirmPassword">Confirm password <span className="required">*</span></label>
            <input id="confirmPassword" type="password" autoComplete="new-password" placeholder="Repeat password" value={form.confirmPassword}
              onChange={(e) => update('confirmPassword', e.target.value)} onBlur={() => touch('confirmPassword')}
              aria-invalid={!!visibleError('confirmPassword')} />
            <FieldError message={visibleError('confirmPassword')} id="confirm-password-error" />
          </div>
          <fieldset className="form-field field-wide interest-field" onBlur={() => touch('interests')}>
            <legend>Academic interests <span className="required">*</span> <small>Choose at least one</small></legend>
            <div className="interest-options">
              {INTERESTS.map((interest) => (
                <label className={`interest-option ${form.interests.includes(interest) ? 'selected' : ''}`} key={interest}>
                  <input type="checkbox" checked={form.interests.includes(interest)} onChange={() => toggleInterest(interest)} />
                  <span>{interest}</span>
                </label>
              ))}
            </div>
            <FieldError message={visibleError('interests')} id="interests-error" />
          </fieldset>
          <div className="form-field field-wide">
            <div className="label-row"><label htmlFor="bio">Short bio <span className="required">*</span></label><span className="input-counter">{form.bio.trim().length} characters</span></div>
            <textarea id="bio" rows={4} placeholder="Tell other students what you are studying, creating or curious about..."
              value={form.bio} onChange={(e) => update('bio', e.target.value)} onBlur={() => touch('bio')}
              aria-invalid={!!visibleError('bio')} />
            <FieldError message={visibleError('bio')} id="bio-error" />
          </div>
          <div className="form-field field-wide terms-field">
            <label className="terms-label">
              <input type="checkbox" checked={form.acceptedTerms} onChange={(e) => update('acceptedTerms', e.target.checked)} onBlur={() => touch('acceptedTerms')} />
              <span>I agree to share respectful, academic-focused content and follow the <Link to="/about" title="Read the community guidelines on the About page">community guidelines</Link>.</span>
            </label>
            <FieldError message={visibleError('acceptedTerms')} id="terms-error" />
          </div>
        </div>
        <button className="button button-primary register-button" type="submit">Create my profile <span aria-hidden="true">→</span></button>
        <p className="form-security-note">This is a browser-only classroom demonstration. No password is stored in localStorage.</p>
      </form>
      <div className="preview-column">
        <div className="preview-intro"><span className="eyebrow">YOUR DIGITAL INTRODUCTION</span><h2>See your profile take shape.</h2><p>Your details appear instantly in the preview as you complete the form.</p></div>
        <ProfilePreview fullName={form.fullName} bio={form.bio} campus={form.campus} interests={form.interests} />
      </div>
    </div>
  );
}
export default SignUpForm;
