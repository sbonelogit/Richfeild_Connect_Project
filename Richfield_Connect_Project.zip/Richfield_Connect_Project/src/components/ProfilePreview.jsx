import { getInitials } from '../utils/formatters';

// Props, not a second useState, make the preview update on every keystroke.
function ProfilePreview({ fullName, bio, campus, interests }) {
  return (
    <aside className="preview-card" aria-label="Live profile preview">
      <div className="preview-topline"><span className="live-indicator" /> LIVE PREVIEW <span className="preview-hint">As you type</span></div>
      <div className="preview-cover"><span className="cover-shape shape-one" /><span className="cover-shape shape-two" /></div>
      <div className="preview-content">
        <div className="avatar avatar-large">{getInitials(fullName)}</div>
        <h3>{fullName.trim() || 'Your name goes here'}</h3>
        <p className="muted preview-campus">{campus || 'Your campus'} <span aria-hidden="true">·</span> Student member</p>
        <div className="preview-divider" />
        <p className="label-uppercase">About me</p>
        <p className="preview-bio">{bio.trim() || 'A little introduction about you will appear here as you write your bio.'}</p>
        <p className="label-uppercase">Interests</p>
        <div className="tag-list">
          {interests.length ? interests.map((interest) => <span className="tag" key={interest}>{interest}</span>)
            : <span className="muted preview-placeholder">Your interests will appear here</span>}
        </div>
      </div>
      <div className="preview-footer">✧ Your academic identity starts here.</div>
    </aside>
  );
}
export default ProfilePreview;
