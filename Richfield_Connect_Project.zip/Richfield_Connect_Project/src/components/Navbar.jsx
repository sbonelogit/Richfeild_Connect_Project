import { Link, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { getInitials } from '../utils/formatters';
import { NAV_LINKS } from '../utils/constants';

function Brand() {
  return (
    <span className="brand-lockup">
      <span className="brand-emblem" aria-hidden="true">
        <svg viewBox="0 0 40 40" fill="none">
          <path d="M5 15 20 7l15 8-15 8L5 15Z" fill="currentColor" />
          <path d="M11 22v7c6 5 12 5 18 0v-7l-9 5-9-5Z" fill="currentColor" opacity=".58" />
          <path d="M35 16v12" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      </span>
      <span className="brand-wordmark"><strong>RICHFIELD</strong><small>CONNECT <span className="brand-dot">●</span></small></span>
    </span>
  );
}

function Navbar() {
  const { pathname } = useLocation();
  const { user } = useAppContext();

  return (
    <header className="site-header">
      <div className="container navigation">
        <Link to="/" className="brand-link" aria-label="Richfield Connect home"><Brand /></Link>
        <nav className="main-nav" aria-label="Main navigation">
          {NAV_LINKS.map(({ label, path }) => (
            <Link key={path} to={path} className={`nav-link ${pathname === path ? 'is-active' : ''}`}
              aria-current={pathname === path ? 'page' : undefined}>
              {label}
            </Link>
          ))}
        </nav>
        <div className="nav-actions">
          {user ? (
            <Link className="user-pill" to="/profile" title="View profile">
              <span className="small-avatar">{getInitials(user.fullName)}</span>
              <span className="user-pill-label">My account</span>
            </Link>
          ) : <Link className="button button-small button-primary" to="/signup">Join the community <span aria-hidden="true">↗</span></Link>}
        </div>
      </div>
    </header>
  );
}

export default Navbar;
