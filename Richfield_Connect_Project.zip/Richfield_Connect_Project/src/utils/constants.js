// Centralised demo data keeps dropdowns and navigation consistent across views.
export const CAMPUSES = ['Durban', 'Johannesburg', 'Cape Town', 'Pretoria', 'Gqeberha'];
export const INTERESTS = [
  'Programming',
  'UI / UX Design',
  'Data Science',
  'Networking',
  'Cybersecurity',
  'Entrepreneurship',
];
export const NAV_LINKS = [
  { label: 'Home', path: '/' },
  { label: 'About', path: '/about' },
  { label: 'Community feed', path: '/feed' },
  { label: 'My profile', path: '/profile' },
];
export const STORAGE_KEYS = {
  profile: 'richfield-connect-profile-v1',
  posts: 'richfield-connect-posts-v1',
};
