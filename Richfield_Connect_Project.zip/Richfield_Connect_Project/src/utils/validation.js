import { CAMPUSES } from './constants';

// A single validation function drives blur errors AND final submission validation.
export function validateRegistration(form) {
  const errors = {};
  if (!form.fullName.trim()) errors.fullName = 'Please enter your full name.';
  if (!/^\d{6,}$/.test(form.studentNumber)) {
    errors.studentNumber = 'Enter at least 6 digits (numbers only).';
  }
  if (!CAMPUSES.includes(form.campus)) errors.campus = 'Select a campus.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
    errors.email = 'Enter a valid email address.';
  }
  if (form.password.length < 8) errors.password = 'Use at least 8 characters.';
  if (form.confirmPassword !== form.password || !form.confirmPassword) {
    errors.confirmPassword = 'Passwords must match.';
  }
  if (form.interests.length === 0) errors.interests = 'Choose at least one interest.';
  if (form.bio.trim().length < 20) errors.bio = 'Write a bio of at least 20 characters.';
  if (!form.acceptedTerms) errors.acceptedTerms = 'Accept the terms to continue.';
  return errors;
}
