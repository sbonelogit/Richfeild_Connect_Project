export function getInitials(fullName = '') {
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  return parts.slice(0, 2).map((part) => part[0].toUpperCase()).join('') || 'RC';
}

export function formatMemberDate(dateValue) {
  if (!dateValue) return 'Recently joined';
  const date = new Date(dateValue);
  return Number.isNaN(date.getTime())
    ? 'Recently joined'
    : new Intl.DateTimeFormat('en-ZA', { month: 'long', year: 'numeric' }).format(date);
}

export function readableTimestamp(date = new Date()) {
  return new Intl.DateTimeFormat('en-ZA', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date);
}

export function uniqueId() {
  return typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
