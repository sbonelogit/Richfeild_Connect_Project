import { createContext, useContext, useEffect, useMemo, useReducer } from 'react';
import { STORAGE_KEYS } from '../utils/constants';
import { readStoredJson, writeStoredJson } from '../utils/storage';

const AppContext = createContext(null);
const initialState = { user: null, posts: [], hydrated: false };

function appReducer(state, action) {
  switch (action.type) {
    case 'HYDRATE':
      return { ...state, ...action.payload, hydrated: true };
    case 'REGISTER_USER':
      return { ...state, user: action.payload };
    case 'ADD_POST':
      return { ...state, posts: [action.payload, ...state.posts] };
    case 'UPDATE_POST':
      return {
        ...state,
        posts: state.posts.map((post) =>
          post.id === action.payload.id ? { ...post, content: action.payload.content, edited: true } : post
        ),
      };
    case 'TOGGLE_LIKE':
      return {
        ...state,
        posts: state.posts.map((post) => {
          if (post.id !== action.payload) return post;
          const liked = !post.liked;
          return { ...post, liked, likes: Math.max(0, post.likes + (liked ? 1 : -1)) };
        }),
      };
    case 'DELETE_POST':
      return { ...state, posts: state.posts.filter((post) => post.id !== action.payload) };
    case 'ADD_COMMENT':
      return {
        ...state,
        posts: state.posts.map((post) =>
          post.id === action.payload.postId
            ? { ...post, comments: [...(post.comments || []), action.payload.comment] }
            : post
        ),
      };
    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // First mount: restore profile and posts before allowing the save effect to run.
  useEffect(() => {
    const storedUser = readStoredJson(STORAGE_KEYS.profile, null);
    const storedPosts = readStoredJson(STORAGE_KEYS.posts, []);
    // Ignore malformed values rather than crashing the profile or post-list views.
    const validUser = storedUser && typeof storedUser.fullName === 'string'
      && typeof storedUser.studentNumber === 'string'
      && Array.isArray(storedUser.interests);
    const validPosts = Array.isArray(storedPosts)
      ? storedPosts.filter((post) => post && post.id && typeof post.username === 'string'
        && typeof post.content === 'string' && Number.isFinite(post.likes))
      : [];
    dispatch({
      type: 'HYDRATE',
      payload: {
        user: validUser ? storedUser : null,
        posts: validPosts,
      },
    });
  }, []);

  // The hydrated flag prevents the first blank render from erasing saved data.
  useEffect(() => {
    if (!state.hydrated) return;
    writeStoredJson(STORAGE_KEYS.profile, state.user);
    writeStoredJson(STORAGE_KEYS.posts, state.posts);
  }, [state.user, state.posts, state.hydrated]);

  const value = useMemo(() => ({ ...state, dispatch }), [state]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used inside AppProvider.');
  return context;
}
