import { Link } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import PageHeading from '../components/PageHeading';
import EmptyState from '../components/EmptyState';
import CreatePost from '../components/CreatePost';
import Post from '../components/Post';

function Feed() {
  const { user, posts, hydrated } = useAppContext();
  return <section className="container page-section feed-page"><PageHeading eyebrow="COMMUNITY HUB" title="The conversation starts here." description="Ideas, questions and small wins from students building something better together." />
    <div className="feed-layout"><div className="feed-main">
      {!hydrated ? <p className="loading-message">Loading community posts…</p> : !user ? <EmptyState title="Join the discussion." text="Create your profile to share posts, appreciate great ideas and join the conversation." action="Register to participate" to="/signup" icon="✎" /> : <CreatePost />}
      <div className="feed-list-heading"><h2>Community posts</h2><span>{posts.length} {posts.length === 1 ? 'post' : 'posts'}</span></div>
      {hydrated && (posts.length ? <div className="post-list">{posts.map((post) => <Post key={post.id} post={post} />)}</div> : <EmptyState icon="◇" title="A blank page full of possibilities." text={user ? 'Be the first to share a question, study tip or small victory with your fellow students.' : 'Community posts will show up here once someone shares an idea.'} />)}
    </div><aside className="feed-sidebar"><div className="side-card feed-welcome"><span className="eyebrow">YOUR CAMPUS COMMUNITY</span><div className="community-icon">✧</div><h3>Good conversations grow great ideas.</h3><p>Keep it thoughtful, keep it kind and give others a reason to join in.</p><Link className="text-link" to="/about">View community guidelines ↗</Link></div><div className="feed-sidebar-tip"><span>✦ CAMPUS TIP</span><p>Try sharing a helpful learning resource or one question you would love to explore.</p></div></aside></div>
  </section>;
}
export default Feed;
