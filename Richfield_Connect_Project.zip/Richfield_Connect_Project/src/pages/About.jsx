import { Link } from 'react-router-dom';
import PageHeading from '../components/PageHeading';

const guidelines = [
  { title: 'Lead with respect', description: 'Be polite to fellow students even when ideas or opinions differ.' },
  { title: 'Keep it academic', description: 'Share content that supports learning, career growth and student life.' },
  { title: 'Give credit', description: 'Acknowledge authors and sources when sharing others’ work or ideas.' },
  { title: 'Protect privacy', description: 'Never publish passwords, private records or another person’s data.' },
  { title: 'Build others up', description: 'Offer constructive feedback, encourage others and avoid harassment.' },
];

function About() {
  return (
    <>
      <section className="container page-section"><PageHeading eyebrow="OUR PURPOSE" title="More than a platform. A place to belong." description="Richfield Connect brings academic conversations, collaboration and student identity into one thoughtful digital space." />
        <div className="about-story-grid"><div className="about-story-card"><span className="eyebrow">WHY WE EXIST</span><h2>Connection makes learning <em>more meaningful.</em></h2><p>Richfield Connect is a dedicated academic community where students can discover like-minded peers, celebrate progress, and exchange ideas in a professional environment.</p><p>Unlike commercial social networks, it is designed around collaboration, academic integrity and mutual respect.</p><Link to="/signup" className="text-link">Be part of the community <span aria-hidden="true">↗</span></Link></div><div className="about-values"><div><span>01 /</span><h3>Curiosity</h3><p>Ask good questions and keep learning.</p></div><div><span>02 /</span><h3>Community</h3><p>Build strong connections beyond the classroom.</p></div><div><span>03 /</span><h3>Integrity</h3><p>Share thoughtfully and credit original sources.</p></div></div></div>
      </section>
      <section className="guidelines-section"><div className="container"><div className="section-header-line"><div><span className="eyebrow">COMMUNITY GUIDELINES</span><h2>Make this space better<br />for everyone.</h2></div><p>Five simple principles help keep Richfield Connect supportive and professionally focused.</p></div><ol className="guidelines-grid">{guidelines.map((item, index) => <li key={item.title}><span className="guideline-num">0{index + 1}</span><h3>{item.title}</h3><p>{item.description}</p></li>)}</ol></div></section>
      <section className="container contact-section"><div><span className="eyebrow">GET IN TOUCH</span><h2>Need a little guidance?</h2><p>This classroom prototype includes demo contact information, not an official institutional support channel.</p></div><div className="contact-box"><div><span className="contact-icon">✉</span><div><strong>Demo contact</strong><a href="mailto:@richfieldconnect.example">richfieldconnect.ac.za</a></div></div><div><span className="contact-icon">⌖</span><div><strong>Campus location</strong><span>Durban, KwaZulu-Natal, South Africa</span></div></div></div></section>
    </>
  );
}
export default About;
