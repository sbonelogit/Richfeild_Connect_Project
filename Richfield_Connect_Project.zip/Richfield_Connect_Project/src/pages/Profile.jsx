import { Link } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { getInitials, formatMemberDate } from '../utils/formatters';
import EmptyState from '../components/EmptyState';
import PageHeading from '../components/PageHeading';

function Profile() {
  const { user, posts, hydrated } = useAppContext();
  if (!hydrated) return <section className="container page-section"><p className="loading-message">Loading your profile…</p></section>;
  if (!user) return <section className="container page-section"><EmptyState icon="♧" title="Your story starts with a profile." text="Register to build your student identity, select your interests and connect with the community." action="Create a profile" to="/signup" /></section>;

  const myPosts = posts.filter((post) => post.authorStudentNumber === user.studentNumber);
  const stats = [
    { label: 'Posts', value: myPosts.length },
    { label: 'Connections', value: 0 }, // Static display metric requested by the brief.
    { label: 'Groups', value: 0 },       // No group-management feature is required.
  ];
  return <section className="container page-section profile-page"><PageHeading eyebrow="MY STUDENT PROFILE" title="A little about me." description="Your academic identity, interests and community activity — all in one place." />
    <div className="profile-grid"><article className="profile-main-card"><div className="profile-banner"><span>RICHFIELD CONNECT</span><div className="banner-decoration">✧</div></div><div className="profile-body"><div className="avatar profile-avatar">{getInitials(user.fullName)}</div><div className="profile-identity"><span className="member-label">✓ STUDENT MEMBER</span><h2>{user.fullName}</h2><p>{user.campus} campus <span aria-hidden="true">·</span> Member since {formatMemberDate(user.registeredAt)}</p></div>
      <div className="stats-row">{stats.map((stat) => <div className="stat-item" key={stat.label}><strong>{stat.value}</strong><span>{stat.label}</span></div>)}</div>
      <div className="profile-section"><h3>About me</h3><p>{user.bio}</p></div>
      <div className="profile-section"><h3>Academic interests</h3><div className="tag-list">{user.interests.map((interest) => <span className="tag" key={interest}>{interest}</span>)}</div></div>
    </div></article><aside className="profile-side"><div className="side-card"><span className="eyebrow">STUDENT DETAILS</span><div className="detail-row"><span>Student number</span><strong>{user.studentNumber}</strong></div><div className="detail-row"><span>Email</span><strong className="break-word">{user.email}</strong></div><div className="detail-row"><span>Campus</span><strong>{user.campus}</strong></div><div className="detail-row"><span>Community terms</span><strong>{user.acceptedTerms ? 'Accepted' : 'Not accepted'}</strong></div></div><div className="side-action-card"><span className="side-action-icon">✎</span><h3>Have something to share?</h3><p>Start a conversation, swap a study tip or post your latest project milestone.</p><Link to="/feed" className="button button-white">Explore the feed <span aria-hidden="true">↗</span></Link></div></aside></div>
  </section>;
}
export default Profile;
