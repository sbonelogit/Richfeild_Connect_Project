import PageHeading from '../components/PageHeading';
import SignUpForm from '../components/SignUpForm';

function SignUp() {
  return <section className="container page-section signup-page"><PageHeading eyebrow="JOIN RICHFIELD CONNECT" title="Your community journey begins here." description="Introduce yourself, discover your peers and start sharing ideas that matter." /><SignUpForm /></section>;
}
export default SignUp;
