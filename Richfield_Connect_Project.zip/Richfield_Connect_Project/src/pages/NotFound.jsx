import EmptyState from '../components/EmptyState';
function NotFound() {
  return <section className="container page-section"><EmptyState icon="?" title="This page has wandered off campus." text="The link may be outdated. You can always find your way back to the Richfield Connect home page." action="Back to home" to="/" /></section>;
}
export default NotFound;
