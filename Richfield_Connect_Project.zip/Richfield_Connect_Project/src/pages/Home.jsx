import { Link } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

const features = [
  { number: '01', icon: '◎', title: 'Find your people', description: 'Meet students who share your subjects, projects and big ideas.', className: 'feature-blue' },
  { number: '02', icon: '✎', title: 'Share what you know', description: 'Trade study tips, ask questions and celebrate academic wins.', className: 'feature-gold' },
  { number: '03', icon: '✧', title: 'Grow your identity', description: 'Create an academic profile that tells your story and interests.', className: 'feature-sky' },
];

function Home() {
  const { user, posts } = useAppContext();
  return (
    <>
      <section className="hero"><div className="container hero-grid">
        <div className="hero-copy"><span className="hero-eyebrow"><span className="live-indicator" /> THE STUDENT COMMUNITY PLATFORM</span><h1>Ideas are better <em>together.</em></h1><p>Meet curious minds, exchange knowledge and make your academic journey a shared experience. Welcome to Richfield Connect.</p>
          <div className="hero-actions"><Link className="button button-white" to={user ? '/feed' : '/signup'}>{user ? 'Explore the feed' : 'Join Richfield Connect'} <span aria-hidden="true">↗</span></Link><Link className="hero-learn-link" to="/about">See how it works <span aria-hidden="true">→</span></Link></div>
          <div className="hero-note"><span className="tiny-star">✦</span> Built for students. Powered by shared ambition.</div>
        </div>
        <div className="hero-art" aria-label="Illustration of campus community conversations" role="img">
          <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" />
          <div className="hero-bubble bubble-top">✦ <span>Great minds connect here</span></div>
          <div className="hero-board"><div className="board-toolbar"><span /><span /><span /><small>RICHFIELD CONNECT</small></div><div className="board-content"><span className="board-kicker">COMMUNITY HIGHLIGHT</span><div className="board-avatars"><b>ZM</b><b>TK</b><b>LN</b><b>+ YOU</b></div><h3>Your next idea<br />starts with <i>a hello.</i></h3><div className="board-underline" /><div className="board-lines"><span /><span /></div><div className="board-footer"><span>♧ LEARN</span><span>♡ SHARE</span><span>✦ GROW</span></div></div></div>
          <div className="hero-bubble bubble-bottom">♥ <span>Community first</span></div>
        </div>
      </div></section>
      <section className="intro-section container"><div className="section-kicker">THE RICHFIELD EXPERIENCE</div><div className="section-header-line"><h2>Everything you need to <span>connect and thrive.</span></h2><p>One welcoming space to build meaningful connections around what matters to you.</p></div>
        <div className="feature-grid">{features.map((item) => <article className={`feature-card ${item.className}`} key={item.number}><div className="feature-top"><span className="feature-icon">{item.icon}</span><span className="feature-number">{item.number}</span></div><h3>{item.title}</h3><p>{item.description}</p><span className="feature-arrow" aria-hidden="true">↗</span></article>)}</div>
      </section>
      <section className="container community-strip"><div className="strip-symbol">✳</div><div><span className="eyebrow">YOUR COMMUNITY AWAITS</span><h2>Make room for your next great conversation.</h2><p>{posts.length ? `${posts.length} community ${posts.length === 1 ? 'post' : 'posts'} and counting.` : 'The next inspiring post could be yours.'}</p></div><Link className="button button-primary" to={user ? '/feed' : '/signup'}>{user ? 'Go to community' : 'Get started for free'} <span aria-hidden="true">↗</span></Link></section>
    </>
  );
}
export default Home;
